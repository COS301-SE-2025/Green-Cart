# Page snapshot

```yaml
- heading "Sign in" [level=1]
- text: Email address
- textbox "Email address"
- text: Password
- textbox "Password"
- checkbox "remember me"
- text: remember me
- link "forgot your password?":
  - /url: /forgot-password
- button "sign in"
- text: Don't have an account?
- link "Sign up":
  - /url: /Register
- text: or
- button "Google Sign in with Google":
  - img "Google"
  - text: Sign in with Google
- img "Green Cart"
- heading "Welcome to Green Cart - where conscious shopping meets convenience." [level=2]
- paragraph: Discover eco-friendly products that support your lifestyle and the planet. Fast, local, and sustainable — shopping that makes a difference.
```