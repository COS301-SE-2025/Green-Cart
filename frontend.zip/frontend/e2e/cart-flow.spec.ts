import { test, expect } from '@playwright/test';

test('user logs in, adds product to cart, places order', async ({ page }) => {
  // Go to the login page
  await page.goto('http://localhost:5173/login'); // adjust if your login route differs

  // Fill in login form
  await page.fill('input[name="email"]', 'nikhil@gmail.com');
  await page.fill('input[name="password"]', 'password');

  // Submit login
  await page.click('button[type="submit"]');

  // Wait for redirect or dashboard appearance
  await expect(page).toHaveURL(/.*dashboard|home/i); // or use a specific element check

  // OPTIONAL: Confirm user_id is stored in localStorage (if applicable)
  const userId = await page.evaluate(() => localStorage.getItem('user_id'));
  expect(userId).not.toBeNull();

  // Go to product listing
  await page.goto('http://localhost:5173/products');

  // Add product to cart (update selector if needed)
  await page.click('button[data-product-id="2"]');

  // Go to cart
  await page.click('a[href="/cart"]');

  // Place order
  await page.click('button#place-order');

  // Confirm order placement
  await expect(page.locator('.order-success')).toContainText('Order placed');
});
