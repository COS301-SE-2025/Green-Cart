from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.cart import Cart, CartItem
from app.schemas.cart import CartItemCreate, CartItemOut, CartOut

router = APIRouter(prefix="/cart", tags=["Cart"])

@router.post("/items", response_model=CartItemOut)
def add_item_to_cart(item: CartItemCreate, db: Session = Depends(get_db)):
    cart = db.query(Cart).filter(Cart.user_id == item.user_id).first()
    if not cart:
        cart = Cart(user_id=item.user_id)
        db.add(cart)
        db.commit()
        db.refresh(cart)

    cart_item = db.query(CartItem).filter(
        CartItem.cart_id == cart.id,
        CartItem.product_id == item.product_id
    ).first()

    if cart_item:
        cart_item.quantity += item.quantity
    else:
        cart_item = CartItem(
            cart_id=cart.id,
            product_id=item.product_id,
            quantity=item.quantity
        )
        db.add(cart_item)

    db.commit()
    db.refresh(cart_item)
    return cart_item


@router.get("", response_model=CartOut)
def get_cart(user_id: str, db: Session = Depends(get_db)):
    cart = db.query(Cart).filter(Cart.user_id == user_id).first()
    if not cart:
        raise HTTPException(status_code=404, detail="Cart not found")

    items = db.query(CartItem).filter(CartItem.cart_id == cart.id).all()
    return {
        "id": cart.id,
        "user_id": cart.user_id,
        "items": items
    }
