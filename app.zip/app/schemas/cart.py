from pydantic import BaseModel
from typing import List

class CartItemCreate(BaseModel):
    user_id: str
    product_id: int
    quantity: int

class CartItemOut(BaseModel):
    id: int
    product_id: int
    quantity: int

    model_config = {
        "from_attributes": True
    }

class CartOut(BaseModel):
    id: int
    user_id: str
    items: List[CartItemOut]

    model_config = {
        "from_attributes": True
    }
